<?php
$glory = new mysqli("localhost","root","","forumapp");
$sql = "SELECT * FROM `topic`";
$result = $glory->query($sql);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <title>Topics page</title>
</head>
<body>
<div>
<?php include "include/navbar.php" ?>
</div>
<div class="container" style="height: 100%; margin-top: 15px;">
<ol class="list-group ">
     <?php
            if($result){
                while ($row = $result -> fetch_row()){

    ?>
 
    <li class="list-group-item  justify-content-between ">
    <span class="badge text-bg-primary rounded-pill" style="position: absolute; right: 10px">14</span>
    <div>
        <div>
            <b>
                <a href="topic-discussion.php?id=<?php echo $row[0]?>">
                    <?= ucwords($row[1]) ?> 
                </a>
            </b>
            <div><small> <?= $row[2]; ?></small></div>
            <?php 

            
                        $sql_inner = "SELECT * FROM `user` left join discussion on user.user_id = discussion.user_id WHERE `topic_id` = $row[0] ORDER BY `discussion`.`discussion` desc limit 3";  
                         $result_inner = $glory->query($sql_inner);
                         echo "<ul style='list-style-type: none; margin: 2px; padding: 8px;'>";
                         while ($row__ = $result_inner -> fetch_assoc()){
                         echo "<li>";  
                         echo($row__['discussion']); 
                         echo "<div>";
                         echo "<small style='color: darkviolet'>".ucwords(($row__['first_name']." ".$row__['last_name']))."</small>";
                         echo "</div>";
                         echo "</li>";
                        }
                        echo "<ul/>"

                          
                   
                   ?>
        </div>
    </div>
    
    </li>
    <?php
                   
                }
               
                 
                
             }
     ?>




</ol>   
</div>
</body>
</html>