<?php
date_default_timezone_set("Africa/Lagos");

$date2=  date_create();

var_dump($date1);
var_dump($date2);


$t1 = strtotime( '2024-07-24 11:55:00' );
$t2 = strtotime( date_format($date2,"Y-m-d H:i:s"));
$diff = ($t1 - $t2) / 60;



