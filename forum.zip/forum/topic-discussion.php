<?php
$discu = isset($_GET['id']) ? $_GET['id'] : 3;
$glory = new mysqli("localhost","root","","forumapp");
$topic_diss = "SELECT * FROM `user` left join discussion on user.user_id = discussion.user_id left join user_profile_image on user_profile_image.user_profile_image_id = user.user_id WHERE `topic_id` = $discu ORDER BY `discussion`.`discussion` ASC;
";


$result = $glory->query($topic_diss);

$topic_ = "SELECT * FROM `topic`  WHERE `topic_id` = $discu";
$result_ = $glory->query($topic_);
$row_ = $result_ ->fetch_assoc();



?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <title>login page</title>
</head>
<body>
<div>
<?php include "include/navbar.php" ?>
</div>
<div class="container" style="height: 100%; ">
<div class="row">

<div class="col-sm-9 p-3">
<div class="my-3 p-3 bg-body rounded shadow-sm">
    <h6 class="border-bottom pb-2 mb-0"><?php  echo ucwords($row_['topic_name']);  ?> <small>(46) contributors</small></h6> 
<?php
if($result){

    while ($row = $result ->fetch_assoc()){
       $id_ = $row['user_id'];
      
       $sql_activity = "select * from activity_log where user_id = $id ORDER by date DESC limit 1;";
       
       $result___ = $glory->query($sql_activity);
       $row___ = $result___ ->fetch_assoc();
       if($result___->num_rows > 0){
       if( (int)online($row___['date']) < 10){
        $online = true;
        
       }else{
       $online = false;  
       }
    }else{
        $online = false;   
    }
?>
    <div class=" text-body-secondary pt-3 border-bottom">
    <div class="d-flex text-body-secondary pt-3">
      <img class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32" src="assets/user_image/<?php echo $row['user_image']  ?>" />
      <div class="pb-3 mb-0 small lh-sm  w-100">
        <div class="d-flex justify-content-between">
          <strong class="text-gray-dark"><?php echo ucwords(($row['first_name']." ".$row['last_name'])) ?></strong>
         <!-- <a href="#">Follow</a>  -->
        </div>
        <span class="d-block">@username</span>
      </div>
    </div>

<div class=" gap-2 ">
  <p class="pb-3 mb-0 small lh-sm ">
  <?php echo($row['discussion']) ?>
  </p>
</div> 

      <div class="d-flex gap-2 pb-2">
   <span class="badge text-bg-dark"><?= nicetime($row['date'])?></span>
     </div>
     <br>
     
    </div>
 <?php } 
}
 ?>   

  </div>

  </div>
  <div class="col-3 p-3 mb-2">
  <div class="my-3 p-3 bg-body rounded shadow-sm">
    
    <h6 class="border-bottom pb-2 mb-0">Online Users</h6>
    <?php 
    $nestle = "select * from activity_log  ORDER by date DESC limit 1";
    ?>
    <div class="d-flex text-body-secondary pt-3">
      <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#007bff"></rect><text x="50%" y="50%" fill="#007bff" dy=".3em">32x32</text></svg>
      <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
        <div class="d-flex justify-content-between">
          <strong class="text-gray-dark">Full Name</strong>
          <a href="#">Follow</a>
        </div>
        <span class="d-block">@username</span>
      </div>
    </div>
    <div class="d-flex text-body-secondary pt-3">
      <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#007bff"></rect><text x="50%" y="50%" fill="#007bff" dy=".3em">32x32</text></svg>
      <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
        <div class="d-flex justify-content-between">
          <strong class="text-gray-dark">Full Name</strong>
          <a href="#">Follow</a>
        </div>
        <span class="d-block">@username</span>
      </div>
    </div>
    <div class="d-flex text-body-secondary pt-3">
      <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#007bff"></rect><text x="50%" y="50%" fill="#007bff" dy=".3em">32x32</text></svg>
      <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
        <div class="d-flex justify-content-between">
          <strong class="text-gray-dark">Full Name</strong>
          <a href="#">Follow</a>
        </div>
        <span class="d-block">@username</span>
      </div>
    </div>
    <small class="d-block text-end mt-3">
      <a href="#">All online users</a>
    </small>
  </div>
</div>

</div>

  <center><nav aria-label="Page navigation example">
  <ul class="pagination">
    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item"><a class="page-link" href="#">Next</a></li>
  </ul>
</nav></center>

</div>
<div>
 <DIV>

 </DIV>
 <DIV>

 </DIV>

</div>

</body>
<?PHP
function nicetime($date)
{
    if(empty($date)) {
        return "No date provided";
    }
    
    $periods         = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
    $lengths         = array("60","60","24","7","4.35","12","10");
    
    $now             = time();
    $unix_date       = strtotime($date);
    
       // check validity of date
    if(empty($unix_date)) {    
        return "Bad date";
    }

    // is it future date or past date
    if($now > $unix_date) {    
        $difference     = $now - $unix_date;
        $tense         = "ago";
        
    } else {
        $difference     = $unix_date - $now;
        $tense         = "from now";
    }
    
    for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
        $difference /= $lengths[$j];
    }
    
    $difference = round($difference);
    
    if($difference != 1) {
        $periods[$j].= "s";
    }
    
    return "$difference $periods[$j] {$tense}";
}


function online($date1){
    date_default_timezone_set("Africa/Lagos");
$date2=  date_create();
//var_dump($date1);
//var_dump($date2);
$t1 = strtotime( $date1 );
$t2 = strtotime( date_format($date2,"Y-m-d H:i:s"));
$diff = ($t2 - $t1) / 60;
return $diff;
}
?>