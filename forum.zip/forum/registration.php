<?php 
session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <title>login page</title>
</head>
<body>
<div>
<?php include "include/navbar.php" ?>
</div>
<div class="container">
  <center><h2>User Registration</h2></center>
  <?php
   if(!empty($_GET['err'])){
     
     echo  $_GET['err'];
     echo "<br/>";
   }
  ?>
    <br/>
    <form action="registration-process.php"  method="post" <div class="container">
    <div class="jumbotron">
     <label class="form-label" for="fname">First Name</label><br> 
     <input class="form-label" type="text" id="fname" name="fname" required /><br>
     <label class="form-label" for="lname">Last Name</label><br> 
     <input class="form-label" type="text" id="lname" name="lname" required/><br>
     <label class="form-label" for="email">Email</label><br> 
     <input class="form-label"  id="email" name="email"  /><br>
     <label class="form-label" for="pass">Password</label><br> 
     <input class="form-label" type="password" id="pass" name="password" required/><br>
     <input class="btn btn-primary" type="submit" value="submit" />
    </form>
</div>
</body>