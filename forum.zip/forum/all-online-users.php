<?php
$glory = new mysqli("localhost","root","","forumapp");
$sql = "SELECT * FROM `topic`";
$result = $glory->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-avatar@latest/dist/avatar.min.css" rel="stylesheet">
    <title>Deposit Insurance Community</title>

<style>
    .heading{
        color: #20133a;
        font-size: 18px;
        font-size: 1.125rem;
        font-weight: 700;
        line-height: 24px;
        line-height: 1.5rem;
    }


    .pagination {
	list-style-type: none;
	padding: 10px 0;
	display: inline-flex;
	justify-content: space-between;
	box-sizing: border-box;
}
.pagination li {
	box-sizing: border-box;
	padding-right: 10px;
}
.pagination li a {
	box-sizing: border-box;
	background-color: #e2e6e6;
	padding: 8px;
	text-decoration: none;
	font-size: 12px;
	font-weight: bold;
	color: #616872;
	border-radius: 4px;
}
.pagination li a:hover {
	background-color: #d4dada;
}
.pagination .next a, .pagination .prev a {
	text-transform: uppercase;
	font-size: 12px;
}
.pagination .currentpage a {
	background-color: #518acb;
	color: #fff;
}
.pagination .currentpage a:hover {
	background-color: #518acb;
}

</style>
</head>
<div>
<?php include "include/navbar.php" ?>
</div
<body class=""> 
<div class="container">

<div class="container">
  <div class="row mt-3">
  <h6 class="border-bottom pb-2 mb-0">Recent updates</h6>
  <?php
       
       $total_pages = $glory->query("SELECT * FROM user left join activity_log on activity_log.user_id = user.user_id left join user_profile_image on user_profile_image.`user_id`= user.user_id where TIMESTAMPDIFF(SECOND, activity_log.date_, CONCAT(CURDATE(), ' ', CURTIME())) < 6000;")->fetch_row()[0];
       $page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;
       $num_results_on_page = 2;
       $calc_page = ($page - 1) * $num_results_on_page;
       //var_dump($re);
       $re = online_users($calc_page, $num_results_on_page);
      if($re->num_rows > 0){ 
       while( $r = $re->fetch_assoc()){  
        if(isset($r['user_image']))
        $fl = "users/".$r['user_id']."/img/r/".$r['user_image'];
        else
        $fl = "a.jpg";
        ?>  
 <div class="col">
    <div class="d-flex text-body-secondary pt-3">
     
      <img class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="24" height="24" src="<?= $fl ?>" alt="" onError="this.onerror=null;this.src='a.jpg';">
      <p class="pb-3 mb-0 small lh-sm">
        <strong class="d-block text-gray-dark"><?= '@'.$r['username'] ?> </strong>
      </p>
    </div>
 </div>
    <?php }
      
     ?>
   
  
    <?php }else{ ?>
     <center><small class="badge text-bg-warning" style="margin-top: 1.7em;">no users online</small></center>
     <?php } ?>


  
  <?php if (ceil($total_pages / $num_results_on_page) > 0): ?>
    <ul class="pagination">
        <?php if ($page > 1): ?>
        <li class="prev"><a href="all-online-users.php?page=<?php echo $page-1 ?>">Prev</a></li>
        <?php endif; ?>
    
        <?php if ($page > 3): ?>
        <li class="start"><a href="all-online-users.php?page=1">1</a></li>
        <li class="dots">...</li>
        <?php endif; ?>
    
        <?php if ($page-2 > 0): ?><li class="page"><a href="all-online-users.php?page=<?php echo $page-2 ?>"><?php echo $page-2 ?></a></li><?php endif; ?>
        <?php if ($page-1 > 0): ?><li class="page"><a href="all-online-users.php?page=<?php echo $page-1 ?>"><?php echo $page-1 ?></a></li><?php endif; ?>
    
        <li class="currentpage"><a href="all-online-users.php?page=<?php echo $page ?>"><?php echo $page ?></a></li>
    
        <?php if ($page+1 < ceil($total_pages / $num_results_on_page)+1): ?><li class="page"><a href="all-online-users.php?page=<?php echo $page+1 ?>"><?php echo $page+1 ?></a></li><?php endif; ?>
        <?php if ($page+2 < ceil($total_pages / $num_results_on_page)+1): ?><li class="page"><a href="all-online-users.php?page=<?php echo $page+2 ?>"><?php echo $page+2 ?></a></li><?php endif; ?>
    
        <?php if ($page < ceil($total_pages / $num_results_on_page)-2): ?>
        <li class="dots">...</li>
        <li class="end"><a href="all-online-users.php?page=<?php echo ceil($total_pages / $num_results_on_page) ?>"><?php echo ceil($total_pages / $num_results_on_page) ?></a></li>
        <?php endif; ?>
    
        <?php if ($page < ceil($total_pages / $num_results_on_page)): ?>
        <li class="next"><a href="all-online-users.php?page=<?php echo $page+1 ?>">Next</a></li>
        <?php endif; ?>
    </ul>
    <?php endif; ?>
  
  </div>
</div>
</div>
</body>
</html>


<?php 
 function online_users($calc_page, $num_results_on_page){
  $glory = new mysqli("localhost","root","","forumapp");
  $sql = "SELECT * FROM user left join activity_log on activity_log.user_id = user.user_id left join user_profile_image on user_profile_image.`user_id`= user.user_id where TIMESTAMPDIFF(SECOND, activity_log.date_, CONCAT(CURDATE(), ' ', CURTIME())) < 6000 limit $calc_page, $num_results_on_page";
  $result = $glory->query($sql);
  return $result;
  
}
?>
