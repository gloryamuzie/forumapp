<?php
$glory = new mysqli("localhost","root","","forumapp");
$sql = "SELECT * FROM `topic`";
$result = $glory->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-avatar@latest/dist/avatar.min.css" rel="stylesheet">
    <title>Deposit Insurance Community</title>

<style>
    .heading{
        color: #20133a;
        font-size: 18px;
        font-size: 1.125rem;
        font-weight: 700;
        line-height: 24px;
        line-height: 1.5rem;
    }

</style>
</head>

<body class=""> 
<div>
<?php include "include/navbar.php" ?>
</div>
<br/>
<div class="container  align-items-center " style="height: 100%; ">

<div class="row g-0 ">
  <div class="col-sm-6 col-md-8" style="padding-right: 18px;">

  <div class="my-3 p-3 bg-body rounded shadow-sm">
    <h6 class="border-bottom pb-2 mb-0">Hot topics</h6>

   <?php while( $row = $result->fetch_assoc()){  ?>

    <div class=" text-body-secondary pt-3 border-bottom">
      <p class=" mb-0 small lh-sm ">
      <strong class="d-block text-gray-dark"><?= ucwords($row['topic_name'])?></strong>
        
        <?= $row['topic_description']?>
      </p>

      <p>
      
      <div class="d-flex gap-2 ">
    
      <?php
       $re = get_contributors($row['topic_id']);
       while( $r = $re->fetch_assoc()){  
        if(isset($r['user_image']))
        $fl = "users/".$r['user_id']."/img/r/".$r['user_image'];
        else
        $fl = "a.jpg"
        ?>  
  <span class="badge d-flex align-items-center p-1 pe-2 text-primary-emphasis bg-primary-subtle border border-primary-subtle rounded-pill">
    <img class="rounded-circle me-1" width="24" height="24" src="<?= $fl ?>" alt="" onError="this.onerror=null;this.src='a.jpg';"><a href="user-profile-page.php?id=<?=$r['user_id']?>"><?= '@'.$r['username'] ?></a>
  </span>
  <?php } ?>

</div> 
      </p>
      <div class="d-flex gap-2">
      <span class="badge text-bg-light">195+ post</span> <span class="badge text-bg-dark">last post on 16th july 2023</span>
      
    
      <span>contributors (<?= get_contributors_nuber($row['topic_id']); ?>)</s>
     </div>
     <br/>
    </div>
    
   <?php } ?>
    <small class="d-block text-end mt-3">
      <a href="#">All updates</a>
    </small>
  </div>
</div>
<div class="col-6 col-md-4">
   <div style = "width: 300px; ">
   <div class="my-3 p-3 bg-body rounded shadow-sm">
    <h6 class="border-bottom pb-2 mb-0">online users</h6>

    <?php
       $re = online_users();
     
       //var_dump($re);
      if($re->num_rows > 0){ 
       while( $r = $re->fetch_assoc()){  
        if(isset($r['user_image']))
        $fl = "users/".$r['user_id']."/img/r/".$r['user_image'];
        else
        $fl = "a.jpg";
        ?>  

    <div class="d-flex text-body-secondary pt-3">
     
      <img class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="24" height="24" src="<?= $fl ?>" alt="" onError="this.onerror=null;this.src='a.jpg';">
      <p class="pb-3 mb-0 small lh-sm">
        <strong class="d-block text-gray-dark"><?= '@'.$r['username'] ?> </strong>
      </p>
    </div>

    <?php }
      
     ?>
   
    <small class="d-block text-end mt-3">
      <a href="#">All online users</a>
    </small>
    <?php }else{ ?>
     <center><small class="badge text-bg-warning" style="margin-top: 1.7em;">no users online</small></center>
     <?php } ?>


  </div>
   </div>
   <div style = "width: 300px;">

   <div class="my-3 p-3 bg-body rounded shadow-sm">
    <h6 class="border-bottom pb-2 mb-0">Recent post</h6>
    <?php
       $re = recent_post(); 
       while( $r = $re->fetch_assoc()){ 
        if(isset($r['user_image']))
        $fl = "users/".$r['user_id']."/img/r/".$r['user_image'];
        else
        $fl = "a.jpg"
        ?>  
   <div class="d-flex text-body-secondary pt-3">
   <img class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="24" height="24" src="<?= $fl ?>" alt="" onError="this.onerror=null;this.src='a.jpg';">
      <p class="pb-3 mb-0 small lh-sm border-bottom">
        <strong class="d-block text-gray-dark"><?= '@'.$r['username'] ?> </strong>
        <?= limit_text($r['discussion']) ?> 
      </p>
    </div>
   
    <?php }?>
    <?php 
    
    
   ?>
  
    <small class="d-block text-end mt-3">
      <a href="topic.php">All posts</a>
    </small>
  </div>
   </div>
   </div>
   
  </div>
</div>
</div>
</body>
</html>

<?php 
function get_contributors_nuber($topic_id){
  $glory = new mysqli("localhost","root","","forumapp");
  $sql = "SELECT COUNT(DISTINCT(`user_id`)) as contributors FROM `discussion` WHERE `topic_id` = $topic_id;";
  $result = $glory->query($sql);
  $row = $result ->fetch_assoc();
  return $row['contributors'];
  
}

function get_contributors($topic_id){
  $glory = new mysqli("localhost","root","","forumapp");
  $sql = "SELECT DISTINCT(user.user_id),`username`, `user_image` FROM `user` left join discussion on user.user_id = discussion.user_id left join user_profile_image on user.user_id = user_profile_image.user_id WHERE discussion.`topic_id` = $topic_id;";
  $result = $glory->query($sql);
  return $result;
  
}


function online_users(){
  $glory = new mysqli("localhost","root","","forumapp");
  $sql = "SELECT * FROM user left join activity_log on activity_log.user_id = user.user_id left join user_profile_image on user_profile_image.`user_id`= user.user_id where TIMESTAMPDIFF(SECOND, activity_log.date_, CONCAT(CURDATE(), ' ', CURTIME())) < 6000;";
  $result = $glory->query($sql);
  return $result;
  
}

function recent_post(){
  $glory = new mysqli("localhost","root","","forumapp");
 $sql = "SELECT * FROM user left join `discussion` on discussion.user_id = user.user_id left join topic on topic.topic_id = discussion.topic_id left join user_profile_image on user.user_id = user_profile_image.user_id order by discussion.date DESC limit 5;";
 $result = $glory->query($sql);
 return $result;
}

function last_post(){
  $glory = new mysqli("localhost","root","","forumapp");
  $sql = "SELECT `date_`FROM `user` LEFT JOIN discussion ON discussion.user_id = user.user_id LEFT JOIN activity_log ON user.user_id = activity_log.user_id";
  $result = $glory->query($sql);
  return $result;

}

function limit_text($string){
  $string = strip_tags($string);
  if (strlen($string) > 500) {
  
  
  $stringCut = substr($string, 0, 500);
  $endPoint = strrpos($stringCut, ' ');
  
  $string = $endPoint? substr($stringCut, 0, $endPoint) : substr($stringCut, 0);
  $string .= '... <a href="/this/story">Read More</a>';
  }
 return $string;
}

?>

