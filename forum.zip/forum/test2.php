<?php
$ar = ["Abigail" , "John" , "Paul"];


for( $r = 0; $r <= 2; $r= $r + 1){
   
echo "<br/>" . $ar[$r];

}



echo "<br/>i am  ". $ar[0];

?>