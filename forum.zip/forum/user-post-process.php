<?php
session_start();
$liveuser = ($_SESSION['login-user']);
var_dump($_GET);
$glory = new mysqli("localhost","root","","forumapp"); 
$mypost = $_POST['mypost'];
$usertopics = $_POST['usertopic'];
$newsql = "INSERT INTO `discussion`(`dis_id`, `topic_id`, `discussion`, `user_id`, `date`) VALUES (null,'$usertopics','$mypost','$liveuser',now())";
$res = $glory->query($newsql);

if( $res === true ){
  $sql = "INSERT INTO `activity_log`(`activity_log_id`, `user_id`, `activity`) VALUES (null,'$liveuser','post')";
 $result = $glory->query($sql);
}