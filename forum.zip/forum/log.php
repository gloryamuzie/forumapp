<?php

function userlog($activity){
    $id = $_SESSION['login-user'];
    $glory = new mysqli("localhost","root","","forumapp");
    $sql = "INSERT INTO `activity_log`(`user_id`,  `activity`) VALUES ('$id','$activity')";
    $result = $glory->query($sql); 
    if($result){
        return 1;
    }else{
        return 0;
    }
}