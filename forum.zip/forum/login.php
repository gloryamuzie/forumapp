<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <title>login page</title>
</head>
<body class=""> 
<div>
<?php include "include/navbar.php" ?>
</div>
<br/>
<div class="container  align-items-center " style="height: 100%; ">

<div class="row justify-content-md-center " style="height: 100%;">
<div class="col-6 align-items-center" style="height: 100%;">
<form action="login-process.php"  method="post">
     <label for="email">Email</label><br> 
     <input type="email"  class="form-control" id="email" name="email" required /><br>
     <label for="pass">Password</label><br> 
     <input type="password" class="form-control" id="pass" name="password" required/><br>
     <input type="submit" class="btn btn-primary" value="Login" />

     <p><a href="forget-password.php">forgot password</a></p>
</form>
</div>
</div>
</div>
</body>
</html>