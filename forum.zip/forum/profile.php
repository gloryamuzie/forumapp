<?php
//session_start();
//$glory = new mysqli("localhost","root","","forumapp");
//$id = $_SESSION['login-user'];
//$sql = "SELECT * FROM `user` left join user_profile_image on user.user_id = user_profile_image.user_id where user.user_id = $id;";

//$result = $glory->query($sql);
//$row = $result ->fetch_assoc();
//var_dump($row);
//$image_name = $row['user_image'];


//$sql_ = "SELECT * FROM `activity_log` WHERE `user_id`= $id ORDER by `date_` DESC" ;
//$result_ = $glory->query($sql_);
//$row_ = $result_ ->fetch_assoc();


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <title>User Profile</title>
</head>
<body>
<div>
<?php include "include/navbar.php" ?>

<div class="container" style="height: 100%; ">
    <br/>
<div class="container ">
  <div class="row">
    <div class="col-2">
     <div>

      

        <img src='<?php echo "users/$id/img/r/$image_name"?>'  />
 
        
        </div>

     </div>
     <div>
        <form>
        
        </form>
     </div>
     <div>

     </div>
    </div>
    <div class="col-4"> <b></b>
        <table class="table">
        <tr>
            <td><b>Name:</b></td>
            <td><?= $_row['first_name']." ".$_row['last_name'] ?></td>
        </tr>

        <tr>
            <td><b>Role</b></td>
            <td>User</td>
        </tr>

        <tr>
            <td><b>Status</b></td>
            <td>
                <?php
                if($_row['status']== 1){
                    echo 'Active';
                }else 
                echo 'Inactive'; 
             
             ?>
             </td>
        </tr>

        <tr>
            <td><b>Last Active Date</b></td>
            <td><?= $row____['date_'] ?></td>
        </tr>
            
        </table>
   
    </div>

  </div>
  <div class="col-md-5 border-right">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="text-right">Profile Settings</h4>
                </div>
                <form  method="post" action="user-profile-update.php" enctype="multipart/form-data">
                <div class="row mt-2">
                <div class="col-md-12"><label class="labels"><b>Username</b></label><input type="text" class="form-control" name="username" value="<?=$_row['username']?>" placeholder="surname"></div>
                    <div class="col-md-12"><label class="labels"><b>Name</b></label><input type="text" class="form-control" name="fname" placeholder="first name" value="<?= $_row['first_name'] ?>"></div>
                    <div class="col-md-12"><label class="labels"><b>Surname</b></label><input type="text" class="form-control" name="lname" value="<?=$_row['last_name']?>" placeholder="surname"></div>
                </div>

                <div class="row mt-3">
                    <div class="col-md-12"><label class="labels"><b>Mobile Number</b></label><input type="text" class="form-control" name="phone" placeholder="enter phone number" value="<?= $_row['phone_number'] ?>"></div>
                    <div class="col-md-12"><label class="labels"><b>Address</b></label><input type="text" class="form-control" name="address" placeholder="enter address" value="<?= $_row['Address'] ?>"></div>
            
                    <div class="col-md-12"><label class="labels"><b>Email ID</b></label><input type="text" class="form-control" name="email" placeholder="enter email id" value="<?= $_row['email'] ?>"></div>
                    <div class="col-md-12"><label class="labels"><b>Password</b></label><input type="password" class="form-control" name="pass" placeholder="enter password" value="<?= $_row['password'] ?>"></div>
                </div>
                <div class="row mt-3">
                <label class="labels"><b>Change Profile Picture</b></label>
                <input class="form-control" name="image" type="file" id="formFile">
                </div> 
                <div class="mt-2"><button class="btn btn-primary profile-button" type="submit">Update Profile</button></div>
                </form>
            </div>
        </div>

</div>

</div>
</div>
</div>
</div>
</body>
