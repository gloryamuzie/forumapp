<?php
session_start();
if(empty($_POST)){
    header('location: registration.php');
}

$error = array();

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$password = $_POST['password'];
$glory = new mysqli("localhost","root","","forumapp");


if(strlen($password) < 6 ){
    $error[0] = "<b style='color: red'>Password too short</b>";
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error[1] = "<b style='color: red'>incorrect email addrerss</b>";
}

if(empty($error)){

$sql = "INSERT INTO `user` (`user_id`, `first_name`, `last_name`, `email`, `password`) VALUES (null, '$fname', '$lname', '$email', '$password')";
$result = $glory->query($sql);  
$last_id = $glory->insert_id;
if($result === 1){
    echo  "thank you for registring with us :-)";
    mkdir("users/$last_id/profile_image");
}
}else{
    $returned_error = implode('<br/>', $error);
    header('location: registration.php?err='.$returned_error);

}