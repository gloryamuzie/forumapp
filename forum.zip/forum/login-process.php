<?php
session_start();
include 'log.php';
if(empty($_POST)){
  header('location: login.php');
}


$email = $_POST['email'];
$pass =  $_POST['password'];
$glory = new mysqli("localhost","root","","forumapp"); //connnection to the database
$sql = "SELECT * FROM user WHERE email = '$email' and password = '$pass'"; 
$result = $glory->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // echo "welcome" ." ".$row['first_name']." ".$row['last_name'];
     $_SESSION['login-user'] = $row['user_id'];
     userlog("log-in");
     header("location: topic-discussion.php");
}else{

  header('location: login.php?err=Incorrect email address or password&id=3');
}

/*$result = $glory->query("select * from forum_users;");
if ($result->num_rows > 0) {


while ($row = $result->fetch_assoc()) {
var_dump($row);
}

} else {
  echo "no row return";
}
*/


