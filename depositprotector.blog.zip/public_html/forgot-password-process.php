<?php
include "include/dbconnection.php";
$login = strtolower(trim($_POST['email']));
$query = "SELECT * from  user where (lower(username)='$login' OR lower(email) = '$login')"; 
$result = $glory->query($query);
$count= $result->num_rows;
if($count==1)
{
  $user_email_address =  $result-> fetch_assoc()['email'];   
  $token = bin2hex(random_bytes(50));
  $sql = "INSERT INTO `password_reset`(`user_email`, `token`) VALUES ('$user_email_address','$token')";
  $res = $glory->query($sql);
  if($res){
        $FromName="depositprotector.blog";
        $FromEmail="no_reply@depositprotector.blog";
        $ReplyTo="gloryamuzie3@gmail.com";
        $credits="All rights are reserved | Techno Smarter "; 
        $headers  = "MIME-Version: 1.0\n Content-type: text/html; charset=iso-8859-1\n";
        $headers .= "From: ".$FromName." <".$FromEmail.">\n";
        $headers .= "Reply-To: ".$ReplyTo."\n";
        $headers .= "X-Sender: <".$FromEmail.">\n";
        $headers .= "X-Mailer: PHP\n"; 
        $headers .= "X-Priority: 1\n"; 
        $headers .= "Return-Path: <".$FromEmail.">\n"; 
        $subject="You have received password reset email"; 
         $msg="Your password reset link <br> http://depositprotector.blog/password-reset.php?token=".$token." <br> Reset your password with this link .Click or open in new tab<br><br> <br> <br> <center>".$credits."</center>"; 
        if(@mail($user_email_address, $subject, $msg, $headers, '-f'.$FromEmail) ){
            
            echo "yessssssssss";
        header("location:forgot-password.php?sent=1"); 
        exit();
        $hide='1';
          
    }
      
      
  }
}

?>