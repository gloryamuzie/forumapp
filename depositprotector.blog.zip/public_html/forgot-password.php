<!DOCTYPE html>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <title>login page</title>
</head>
<body>
    <?php include "include/navbar.php" ?>
    <div class="d-flex align-items-center bg-body-tertiary h-100">
         


    
<main class="form-signin w-100 m-auto" style="margin-top: -8px;">
    <div class="row justify-content-md-center">
        <div class="col-4">
             <form action="forgot-password-process.php"  method="post">
    <h1 class="h3 mb-3 fw-normal">please enter your email address or username</h1>

    <div class="form-floating">
      <input  name="email" class="form-control" id="floatingInput" placeholder="email address or username ">
      <label for="floatingInput">Email address or username</label>
    </div>
      <br/>

    <button class="btn btn-primary w-100 py-2"  type="submit">Sign in</button>
    <p class="mt-5 mb-3 text-body-secondary">© 2017–2024</p>
  </form>
            
        </div>
        
    </div>
 
</main>
<script src="/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    



    </div>
   
</body>
</html>