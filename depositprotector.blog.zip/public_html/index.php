<?php
$glory = new mysqli("localhost","u633821528_forumapp","]lzd6sR5=Jt2","u633821528_forumapp");
$sql = "SELECT * FROM `topic`";
$result = $glory->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-avatar@latest/dist/avatar.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Deposit Insurance Community</title>

<style>
    .heading{
        color: #20133a;
        font-size: 18px;
        font-size: 1.125rem;
        font-weight: 700;
        line-height: 24px;
        line-height: 1.5rem;
    }

.finsurance  {
    width: 250px;
}

</style>
</head>

<body class=""> 
<div>
<?php include "include/navbar.php" ?>
</div>
<br/>
<div class="container  align-items-center " style="height: 100%; ">
    
 <div style="margin-bottom: 15px;"><h6 class="border-bottom pb-2 mb-0">Check out some deposit insurance systems around the world</h6></div> 
<div class="row" style="border-bottom: 0px solid blue; padding: 15px">
    
    <div class="col">
        <img src="assets/france.svg" class="finsurance" />
    </div>
    
    <div class="col">
        <img src="assets/iadi.png" class="finsurance" />
    </div>
    
<div class="col">
        <img src="assets/dic.png" class="finsurance" />
    </div>
    
    <div class="col">
        <img src="assets/germany.svg" class="finsurance" />
    </div>
    
</div>
<div class="row g-0 ">
  <div class="col-sm-6 col-md-8" style="padding-right: 18px;">

  <div class="my-3 p-3 bg-body rounded shadow-sm">
    <h6 class="border-bottom pb-2 mb-0">Hot topics</h6>

   <?php while( $row = $result->fetch_assoc()){  ?>

    <div class=" text-body-secondary pt-3 border-bottom">
      <p class=" mb-0 small lh-sm ">
      <strong class="d-block text-gray-dark"><?= ucwords($row['topic_name'])?></strong>
        
        <?= $row['topic_description']?>
      </p>

      <div>
      
      <div class="d-flex gap-2 mt-2">
    
      <?php
       $re = get_contributors($row['topic_id']);
       while( $r = $re->fetch_assoc()){  
        if(isset($r['user_image']))
        $fl = "users/".$r['user_id']."/img/r/".$r['user_image'];
        else
        $fl = "a.jpg"
        ?>  
  <span class="badge d-flex align-items-center p-1 pe-2 text-primary-emphasis bg-primary-subtle border border-primary-subtle rounded-pill">
    <img class="rounded-circle me-1" width="24" height="24" src="<?= $fl ?>" alt="" onError="this.onerror=null;this.src='a.jpg';"><a href="user-profile-page.php?id=<?=$r['user_id']?>"><?= '@'.$r['username'] ?></a>
  </span>
  <?php } ?>

</div> 
      </div>
     <?php if(last_post($row['topic_id']) != null){ ?>
      <div class="d-flex gap-2 mt-2">

      <span class="badge text-bg-light">195+ post</span>  <span class="badge text-bg-light"><?= last_post($row['topic_id']) ?></span>
      
    
      <span class="badge text-bg-light">contributors (<?= get_contributors_nuber($row['topic_id']); ?>)</s>
     </div>
     <?php }else{  echo "<div><span class='badge text-bg-secondary'>no post yet</span></div>"; } ?>
     <br/>
    </div>
    
   <?php } ?>
    <small class="d-block text-end mt-3">
      <a class="btn btn-light" href="#"><strong>all updates</strong></a>
    </small>
  </div>
</div>
<div class="col-6 col-md-4">
   <div style = "">
   <div class="my-3 p-3 bg-body rounded shadow-sm">
    <h6 class="border-bottom pb-2 mb-0">Online users</h6>

    <?php
       $re = online_users();
     
       //var_dump($re);
      if($re->num_rows > 0){ 
       while( $r = $re->fetch_assoc()){  
        if(isset($r['user_image']))
        $fl = "users/".$r['user_id']."/img/r/".$r['user_image'];
        else
        $fl = "a.jpg";
        ?>  

    <div class="d-flex text-body-secondary pt-3">
     
      <img class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="24" height="24" src="<?= $fl ?>" alt="" onError="this.onerror=null;this.src='a.jpg';">
      <p class="pb-3 mb-0 small lh-sm">
        <strong class="d-block text-gray-dark"><?= '@'.$r['username'] ?> </strong>
      </p>
    </div>

    <?php }
      
     ?>
   
    <small class="d-block text-end mt-3">
      <a class="btn btn-light" href="#">all online users</a>
    </small>
    <?php }else{ ?>
     <center><small class="badge text-bg-warning" style="margin-top: 1.7em;">no users online</small></center>
     <?php } ?>


  </div>
   </div>
   <div>

   <div class="my-3 p-3 bg-body rounded shadow-sm">
    <h6 class="border-bottom pb-2 mb-0">Recent post</h6>
    <?php
       $re = recent_post(); 
       while( $r = $re->fetch_assoc()){ 
        if(isset($r['user_image']))
        $fl = "users/".$r['user_id']."/img/r/".$r['user_image'];
        else
        $fl = "a.jpg"
        ?>  
   <div class="d-flex text-body-secondary pt-3">
   <img class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="24" height="24" src="<?= $fl ?>" alt="" onError="this.onerror=null;this.src='a.jpg';">
      <p class="pb-3 mb-0 small lh-sm border-bottom">
        <strong class="d-block text-gray-dark"><?= '@'.$r['username'] ?> </strong>
        <?= limit_text($r['discussion']) ?> 
      </p>
    </div>
   
    <?php }?>
    <?php 
    
    
   ?>
  
    <small class="d-block text-end mt-3">
      <a class="btn btn-light" href="topic.php"><strong>more post</strong></a>
    </small>
  </div>
   </div>
   </div>
   
  </div>
</div>
</div>
<?php include "footer.php" ?>
</body>
</html>

<?php 
function get_contributors_nuber($topic_id){
 $glory = new mysqli("localhost","u633821528_forumapp","]lzd6sR5=Jt2","u633821528_forumapp");
  $sql = "SELECT COUNT(DISTINCT(`user_id`)) as contributors FROM `discussion` WHERE `topic_id` = $topic_id;";
  $result = $glory->query($sql);
  $row = $result ->fetch_assoc();
  return $row['contributors'];
  
}

function get_contributors($topic_id){
$glory = new mysqli("localhost","u633821528_forumapp","]lzd6sR5=Jt2","u633821528_forumapp");
  $sql = "SELECT DISTINCT(user.user_id),`username`, `user_image` FROM `user` left join discussion on user.user_id = discussion.user_id left join user_profile_image on user.user_id = user_profile_image.user_id WHERE discussion.`topic_id` = $topic_id;";
  $result = $glory->query($sql);
  return $result;
  
}


function online_users(){
$glory = new mysqli("localhost","u633821528_forumapp","]lzd6sR5=Jt2","u633821528_forumapp");
  $sql = "SELECT * FROM user left join activity_log on activity_log.user_id = user.user_id left join user_profile_image on user_profile_image.`user_id`= user.user_id where TIMESTAMPDIFF(SECOND, activity_log.date_, CONCAT(CURDATE(), ' ', CURTIME())) < 6000;";
  $result = $glory->query($sql);
  return $result;
  
}

function recent_post(){
 $glory = new mysqli("localhost","u633821528_forumapp","]lzd6sR5=Jt2","u633821528_forumapp");
 $sql = "SELECT * FROM user left join `discussion` on discussion.user_id = user.user_id left join topic on topic.topic_id = discussion.topic_id left join user_profile_image on user.user_id = user_profile_image.user_id order by discussion.date DESC limit 5;";
 $result = $glory->query($sql);
 return $result;
}

function last_post($topic_id){
  $glory = new mysqli("localhost","u633821528_forumapp","]lzd6sR5=Jt2","u633821528_forumapp");
  $sql = "SELECT * FROM discussion where topic_id = $topic_id order by date desc limit 1;";
  $result = $glory->query($sql);
  $row = $result ->fetch_assoc();
  return isset($row['date']) ? $row['date'] : null;

}

function limit_text($string){
  $string = strip_tags($string);
  if (strlen($string) > 500) {
  
  
  $stringCut = substr($string, 0, 500);
  $endPoint = strrpos($stringCut, ' ');
  
  $string = $endPoint? substr($stringCut, 0, $endPoint) : substr($stringCut, 0);
  $string .= '... <a href="/this/story">Read More</a>';
  }
 return $string;
}

?>

