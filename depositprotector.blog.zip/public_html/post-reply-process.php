<?php 

session_start();
if(!isset($_SESSION['login-user'])) {   header('location: login.php'); exit();}
$glory = new mysqli("localhost","root","","forumapp");
echo strlen(($_POST['myreply']));
if(strlen(trim($_POST['myreply'])) < 1 )
{
    $prevous_page  = $_SERVER['HTTP_REFERER'];
    header("location: $prevous_page"); exit();
}
$dis_id = $_POST['userpost'];
$reply = trim($_POST['myreply']);
$user_id = $_SESSION['login-user'];
$user_id = $_SESSION['login-user'];
$sql = "INSERT INTO `discussion_reply`( `dis_id`, `reply`, `user_id`) VALUES ('$dis_id','$reply','$user_id')";
$re = $glory->query($sql);
if($re){
 header("location: topic-discussion.php?topic=13");
}

?>