
<?php 
$error = array();
$password = $_POST['password'];
$password_confirm = $_POST['confirmPassword'];

if($password === $password_confirm){
     if (strlen($password) < 8) {
        $error[] = "Password too short!";
    }

    if (!preg_match("#[0-9]+#", $password)) {
        $error[] = "Password must include at least one number!";
    }

    if (!preg_match("#[a-zA-Z]+#", $password)) {
        $error[] = "Password must include at least one letter!";
    }      
}else{
        $error[] = "password do not match";   
}

var_dump($error);


?>