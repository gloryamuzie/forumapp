<?php
session_start();
include "include/dbconnection.php";
if(empty($_POST)){
  header('location: login.php');
}


$email = $_POST['email'];
$pass =  $_POST['password'];
 //connnection to the database
$sql = "SELECT * FROM user WHERE email = '$email' and password = '$pass'"; 
$result = $glory->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // echo "welcome" ." ".$row['first_name']." ".$row['last_name'];
     $_SESSION['login-user'] = $row['user_id'];
     var_dump($_SESSION);
     //header("location: topic-discussion.php");
}else{
    echo "incorrecr password";
    header("location: login.php?err='Incorrect email address or password'");
    exit();
}

/*$result = $glory->query("select * from forum_users;");
if ($result->num_rows > 0) {


while ($row = $result->fetch_assoc()) {
var_dump($row);
}

} else {
  echo "no row return";
}
*/


