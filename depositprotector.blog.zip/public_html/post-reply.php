<!DOCTYPE html>
<?php 
$glory = new mysqli("localhost","root","","forumapp");
$sql = "SELECT * FROM `discussion` WHERE `dis_id` = 13;";
$re = $glory->query($sql);
$row = $re->fetch_assoc();

?>
<html lang="en" style="border: 1px solid green; height: 100%;">
<head>
<meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <title>User Post</title>
</head>
<body style="border: 1px solid pink; height: 100%;">
<div>
<?php include "include/navbar.php" ?>
</div>
<div class="container" style="height: 100%" style="border: 1px solid red; height: 100%;">
  
<div class="vstack gap-3 mt-4" style="border: 0px solid blue; ">
<div class="" style="border: 0px solid red; max-width: 400px;">
<h4>User Post</h4>
<p><?= $row['discussion']?></p>
</div>
<div class="" style="border: 0px solid red; max-width: 400px;">
<form action="post-reply-process.php"  method="post">
    <textarea class="form-control" name="myreply" placeholder="write your reply here"></textarea>
    <input name = "userpost" value = "<?= $row['dis_id'] ?>" hidden />
    <br/>
    <input class="btn btn-primary" type="submit" value="submit" />
     <br/>
    </form>
</div>
</div>
    
    
</div>
</body>