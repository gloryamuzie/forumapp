<!DOCTYPE html>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <title>login page</title>
    <style>
        .form-signin {

    padding: 1rem;
}
    </style>
</head>
<body>
    <?php include "include/navbar.php" ?>
    <div class="d-flex align-items-center bg-body-tertiary" style="height: 80% !important; border: 0px solid red; " >
         

<main class=" w-100 m-auto" style="margin-top: -8px;">
    <div class="row justify-content-md-center">
        <div class="col-4 form-signin">
             <form action="login-process.php"  method="post">
    <h1 class="h3 mb-3 fw-normal">Please sign in</h1>
    <?php  
    if(isset($_GET['err'])){
    ?>
    
    <div class="alert alert-danger alert-dismissible" role="alert">
		<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
			<div class="alert-message">
			<strong><?= $_GET['err'] ?></strong> 
		</div>
	</div>
 
        
    <?php } ?>
    <div class="form-floating">
      <input type="email" name="email" class="form-control" id="floatingInput" placeholder="name@example.com">
      <label for="floatingInput">Email address</label>
    </div>
    <div class="form-floating mt-2">
      <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password">
      <label for="floatingPassword">Password</label>
    </div>

    <div class="form-check text-start my-3">
      <input class="form-check-input" type="checkbox" value="remember-me" id="flexCheckDefault">
      <label class="form-check-label" for="flexCheckDefault">
        Remember me
      </label>
    </div>
    <div style="margin-bottom: 8px;">
    <a  href="forgot-password.php">Have you forgot your password?</a>    
    </div>
    
    <button class="btn btn-primary w-100 py-2"  type="submit">Sign in</button>
    <p class="mt-5 mb-3 text-body-secondary">© 2017–2024</p>
  </form>
            
        </div>
        
    </div>
 
</main>
<script src="/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    



    </div>
   
</body>
</html>