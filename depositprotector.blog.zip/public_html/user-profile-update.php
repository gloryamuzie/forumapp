<?php
session_start();
$glory = new mysqli("localhost","root","","forumapp");
$id = $_SESSION['login-user'];
$username = $_POST['username'];
$password = $_POST['pass'];
$last_name = $_POST['lname'];
$phone_number = $_POST['phone'];
$Address = $_POST['address'];
$email = $_POST['email'];
$first_name = $_POST['fname'];
var_dump($_FILES["image"]);
echo basename($_FILES["image"]["name"]);

if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
    
    $filename = time();
    $destination = "users/$id/img/$filename.jpg";
    if(move_uploaded_file($_FILES["image"]["tmp_name"], $destination)){
                $extension = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
                $originalImage = $file = "users/$id/img/$filename.".$extension;
                $outputImage = "converted/cn.jpg";
                $file = convertImage($originalImage, $outputImage, 100);
                $resized = resize_image($file, 200, 200, $crop=FALSE);
                var_dump($resized);
                $filename_ = "users/$id/img/r/$filename.jpg";
                echo $filename;
                imagejpeg($resized, $filename_);
                //imagejpeg($resized, "v.jpg");
        
                $sql = "SELECT * FROM `user_profile_image` WHERE `user_id` = $id";
                $result = $glory->query($sql);
                if($result->num_rows > 0){
                $sql_i = "UPDATE `user_profile_image` SET `user_image`='$filename.jpg' WHERE `user_id` = $id";  
                $result_ = $glory->query($sql_i);   
                }else{
                $sql_i = "INSERT INTO `user_profile_image`( `user_id`, `user_image`) VALUES ('$id','$filename.jpg')";
                $result_ = $glory->query($sql_i);
                }
}

}else{
    
}
$sql = "UPDATE `user` SET `username`='$username',`password`='$password',`first_name`='$first_name',`last_name`='$last_name',`email`='$email',`Address`='$Address',`phone_number`='$phone_number' WHERE user_id = $id";
$result = $glory->query($sql);
if($result == true){
    echo "<br/>Update Successful";
}else{
    echo "Error";
}







//$url = explode('/', rtrim($url, '/'));
//$url[count($url) - 1] = 'high.jpg';
//$url = implode('/', $url);

//echo $url;

function resize_image($file, $w, $h, $crop=FALSE) {
    list($width, $height) = getimagesize($file);
    $r = $width / $height;
    if ($crop) {
        if ($width > $height) {
            $width = ceil($width-($width*abs($r-$w/$h)));
        } else {
            $height = ceil($height-($height*abs($r-$w/$h)));
        }
        $newwidth = $w;
        $newheight = $h;
    } else {
        if ($w/$h > $r) {
            $newwidth = $h*$r;
            $newheight = $h;
        } else {
            $newheight = $w/$r;
            $newwidth = $w;
        }
    }
    $src = imagecreatefromjpeg($file);
    $dst = imagecreatetruecolor($newwidth, $newheight);
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);

    return $dst;
}


function convertImage($originalImage, $outputImage, $quality)
{
    // jpg, png, gif or bmp?
    $exploded = explode('.',$originalImage);
    $ext = $exploded[count($exploded) - 1]; 

    if (preg_match('/jpg|jpeg/i',$ext))
        $imageTmp=imagecreatefromjpeg($originalImage);
    else if (preg_match('/png/i',$ext))
        $imageTmp=imagecreatefrompng($originalImage);
    else if (preg_match('/gif/i',$ext))
        $imageTmp=imagecreatefromgif($originalImage);
    else if (preg_match('/bmp/i',$ext))
        $imageTmp=imagecreatefrombmp($originalImage);
    else
        return 0;

    // quality is a value from 0 (worst) to 100 (best)
    imagejpeg($imageTmp, $outputImage, $quality);
    imagedestroy($imageTmp);

    return $outputImage;
} 
?>