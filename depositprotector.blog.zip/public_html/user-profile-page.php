<?php
$_user_ = $_GET['id'];
$glory = new mysqli("localhost","u633821528_forumapp","]lzd6sR5=Jt2","u633821528_forumapp");
$sql = "SELECT * FROM `user` where user_id = $_user_";
$re = $glory->query($sql);
$r = $re->fetch_assoc(); 
        if(isset($r['user_image']))
        $fl = "users/".$r['user_id']."/img/r/".$r['user_image'];
        else
        $fl = "a.jpg";
        
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-avatar@latest/dist/avatar.min.css" rel="stylesheet">
    <title>Deposit Insurance Community</title>

<style>
    .heading{
        color: #20133a;
        font-size: 18px;
        font-size: 1.125rem;
        font-weight: 700;
        line-height: 24px;
        line-height: 1.5rem;
    }
    body{margin-top:20px;
background: #f5f5f5;
}
.theme-bg-white {
    background-color: #fff !important;
}
.ui-w-100 {
    width: 100px !important;
    height: auto;
}
.ui-w-40 {
    width: 40px !important;
    height: auto;
}
.row-bordered>.col::before, .row-bordered>[class^="col-"]::before, .row-bordered>[class*=" col-"]::before, .row-bordered>[class^="col "]::before, .row-bordered>[class*=" col "]::before, .row-bordered>[class$=" col"]::before, .row-bordered>[class="col"]::before {
    content: "";
    position: absolute;
    right: 0;
    bottom: -1px;
    left: 0;
    display: block;
    height: 0;
    border-top: 1px solid rgba(24,28,33,0.06);
}
.row-bordered>.col::after, .row-bordered>[class^="col-"]::after, .row-bordered>[class*=" col-"]::after, .row-bordered>[class^="col "]::after, .row-bordered>[class*=" col "]::after, .row-bordered>[class$=" col"]::after, .row-bordered>[class="col"]::after {
    content: "";
    position: absolute;
    top: 0;
    bottom: 0;
    left: -1px;
    display: block;
    width: 0;
    border-left: 1px solid rgba(24,28,33,0.06);
}

.ui-bg-cover {
    background-color: rgba(0,0,0,0);
    background-position: center center;
    background-size: cover;
}

.ui-square {
    padding-top: 100% !important;
}
.ui-square, .ui-rect, .ui-rect-30, .ui-rect-60, .ui-rect-67, .ui-rect-75 {
    position: relative !important;
    display: block !important;
    padding-top: 100% !important;
    width: 100% !important;
}
</style>
</head>

<body class=""> 
<div>
<?php include "include/navbar.php" ?>
</div>
<br/>
<div class="container  align-items-center " style="height: 100%; ">
<div class="layout-content">

          <!-- Content -->
          <div class="container flex-grow-1 container-p-y">

            <!-- Header -->
            <div class="container-m-nx container-m-ny theme-bg-white mb-4">
              <div class="card-body" style = "padding: 15px;">
              <img src="<?= $fl?>" width="150"  height="150" class="img-thumbnail" alt="..." class="d-block ui-w-100 rounded-circle">
         
                <div class="media-body ml-5">
                  <h4 class="font-weight-bold mb-4"><?= $r['first_name']." ".$r['last_name']   ?></h4>
                 
                </div>
              </div>
              <hr class="m-0">
            </div>
            <!-- Header -->

            <div class="row">
              <div class="col">

                <!-- Info -->
                <div class="card mb-4">
                  <div class="card-body">
                      <!--
                    <div class="row mb-2">
                      <div class="col-md-3 text-muted">Birthday:</div>
                      <div class="col-md-9">
                        May 3, 1995
                      </div>
                    </div>
-->
                    <div class="row mb-2">
                      <div class="col-md-3 text-muted">Country:</div>
                      <div class="col-md-9">
                        <a href="javascript:void(0)" class="text-body"><?= $r['country']?></a>
                      </div>
                    </div>


                    <h6 class="my-3">Contacts</h6>

                    <div class="row mb-2">
                      <div class="col-md-3 text-muted">Phone:</div>
                      <div class="col-md-9">
                      <?= $r['phone_number']?>
                      </div>
                    </div>

                    <h6 class="my-3">Post</h6>

                    <div class="row mb-2">
                      <div class="col-md-3 text-muted">number of post</div>
                      <div class="col-md-9">
                      <span class="badge text-bg-primary"><?= user_post_count($_user_) ?></span>
                      </div>
                    </div>
<!--
                    <h6 class="my-3">Interests</h6>

                    <div class="row mb-2">
                      <div class="col-md-3 text-muted">Favorite music:</div>
                      <div class="col-md-9">
                        <a href="javascript:void(0)" class="text-body">Rock</a>,
                        <a href="javascript:void(0)" class="text-body">Alternative</a>,
                        <a href="javascript:void(0)" class="text-body">Electro</a>,
                        <a href="javascript:void(0)" class="text-body">Drum &amp; Bass</a>,
                        <a href="javascript:void(0)" class="text-body">Dance</a>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-md-3 text-muted">Favorite movies:</div>
                      <div class="col-md-9">
                        <a href="javascript:void(0)" class="text-body">The Green Mile</a>,
                        <a href="javascript:void(0)" class="text-body">Pulp Fiction</a>,
                        <a href="javascript:void(0)" class="text-body">Back to the Future</a>,
                        <a href="javascript:void(0)" class="text-body">WALL·E</a>,
                        <a href="javascript:void(0)" class="text-body">Django Unchained</a>,
                        <a href="javascript:void(0)" class="text-body">The Truman Show</a>,
                        <a href="javascript:void(0)" class="text-body">Home Alone</a>,
                        <a href="javascript:void(0)" class="text-body">Seven Pounds</a>
                      </div>
                    </div>
-->
                  </div>
                  <div class="card-footer text-center p-0">
               
                  </div>
                </div>
                <!-- / Info -->

                <!-- Posts -->
                <?php $result = user_post($_user_);
                 while( $row = $result->fetch_assoc()){ 
                    if(isset($row['user_image']))
                    $fl = "users/".$row['user_id']."/img/r/".$row['user_image'];
                    else
                    $fl = "a.jpg";
                    ?>  
           
                <div class="card mb-4">

                  <div class="card-body">
                  <p class="fw-bolder">Topic : <?= $row['topic_name'] ?><div><small><?= $row['date'] ?></small></div></p>
                  
                    <p>
                     <?= $row['discussion'] ?>
                    </p>
                   
              
                  </div>
               <?php } ?>
                </div>

                <!-- / Posts -->

              </div>
              <div class="col-xl-4">

                <!-- Side info -->
             
         

              </div>
            </div>

          </div>
          <!-- / Content -->


        </div>
</div>
</body>
</html>



<?php
function user_post($id){
   $glory = new mysqli("localhost","u633821528_forumapp","]lzd6sR5=Jt2","u633821528_forumapp");
   $sql = "SELECT * FROM user left join `discussion` on discussion.user_id = user.user_id left join topic on topic.topic_id = discussion.topic_id left join user_profile_image on user.user_id = user_profile_image.user_id where user.user_id = $id order by discussion.date DESC ;";
   $result = $glory->query($sql);
   return $result;
  }
  
  function user_post_count($id){
$glory = new mysqli("localhost","u633821528_forumapp","]lzd6sR5=Jt2","u633821528_forumapp");
    $sql = "SELECT COUNT(*) AS UserPostCount FROM `discussion` WHERE `user_id` = $id;";
    $result = $glory->query($sql);
    $row = $result ->fetch_assoc();
    return $row['UserPostCount'];
  }
?>