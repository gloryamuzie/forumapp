<?php

 var_dump($_POST);
if (!empty($_POST)){
     var_dump($_POST);
}


$discu = isset($_GET['id']) ? $_GET['id'] : 3;
include "include/dbconnection.php";
$topic_diss_count = "SELECT count(*) FROM `user` left join discussion on user.user_id = discussion.user_id left join user_profile_image on user_profile_image.user_profile_image_id = user.user_id WHERE `topic_id` = $discu ORDER BY `discussion`.`discussion` ASC;
";
$total_pages = $glory->query($topic_diss_count)->fetch_row()[0];
       $page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;
       $num_results_on_page = 5;
       $calc_page = ($page - 1) * $num_results_on_page;
       //var_dump($re);
$topic_diss = "SELECT user.user_id, user_profile_image.user_image, user.first_name, user.last_name, discussion.discussion, discussion.date, discussion.dis_id FROM `user` left join discussion on user.user_id = discussion.user_id left join user_profile_image on user_profile_image.user_profile_image_id = user.user_id WHERE `topic_id` = $discu ORDER BY `discussion`.`discussion` ASC limit $calc_page, $num_results_on_page;
       ";
$result = $glory->query($topic_diss);

$topic_ = "SELECT * FROM `topic`  WHERE `topic_id` = $discu";
$result_ = $glory->query($topic_);
$row_ = $result_ ->fetch_assoc();



?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <title>Topic - <?= $row_['topic_name']  ?></title>

    <style>
    .heading{
        color: #20133a;
        font-size: 18px;
        font-size: 1.125rem;
        font-weight: 700;
        line-height: 24px;
        line-height: 1.5rem;
    }


    .pagination {
	list-style-type: none;
	padding: 10px 0;
	display: inline-flex;
	justify-content: space-between;
	box-sizing: border-box;
}
.pagination li {
	box-sizing: border-box;
	padding-right: 10px;
}
.pagination li a {
	box-sizing: border-box;
	background-color: #e2e6e6;
	padding: 8px;
	text-decoration: none;
	font-size: 12px;
	font-weight: bold;
	color: #616872;
	border-radius: 4px;
}
.pagination li a:hover {
	background-color: #d4dada;
}
.pagination .next a, .pagination .prev a {
	text-transform: uppercase;
	font-size: 12px;
}
.pagination .currentpage a {
	background-color: #518acb;
	color: #fff;
}
.pagination .currentpage a:hover {
	background-color: #518acb;
}


.chat-item .chat-item-title {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.375rem;
}


.avatar {
    /* width: 2.25rem; */
    height: 3.25rem;
    border-radius: 50%;
    border: 2px solid #f8f9fa;
    background: #f8f9fa;
    color: #fff;
}

.avatar-online {
    /* width: 2.25rem; */
    height: 2.45rem;
    border-radius: 50%;
    border: 2px solid #f8f9fa;
    background: #f8f9fa;
    color: #fff;
}

.media {
    display: flex;
    align-items: flex-start;
}

.chat-item > .media-body {
    margin-left: 0.75rem;
    border-radius: 0.5rem;
    
  
}

.chat-item {
    margin-top: 1.5rem;
    margin-bottom: 1.5rem;
   
}

.chat-module .chat-module-body {
    width: 100%;
    position: absolute;
    top: 4rem;
    height: calc(100% - 4rem);
    overflow-y: scroll;
    padding-right: 1.5rem;
    -ms-overflow-style: none;
}


 .chat-item:not(:last-child),   .online-item:not(:last-child){
    border-bottom: 1px solid #dee2e6;
}
</style>
</head>
<body>
<div>
<?php include "include/navbar.php" ?>
</div>
<div class="container" style="height: 100%; ">
<div class="row">

<div class="col-sm-8 p-3">
    <p><h3><a href="topic-discussion.php?id="<?= $row_['topic_id'] ?>><?php  echo ucwords($row_['topic_name']);  ?></a></h3></p> 
    <div><span>contributions </span><span class="badge text-bg-primary rounded-pill"><?= count_contributors($discu)?></span></div>    
<div class="my-3 p-3 bg-body rounded shadow-sm">

<?php
if($result){

    while ($row = $result ->fetch_assoc()){
       $id_ = $row['user_id'];
      
       $sql_activity = "select * from activity_log where user_id = $id_ ORDER by date_ DESC limit 1;";
      
       $result___ = $glory->query($sql_activity);
      
       $row___ = $result___ ->fetch_assoc();
      
       if($result___->num_rows > 0){
       if( (int)online($row___['date_']) < 10){
        $online = true;
        
       }else{
       $online = false;  
       }
    }else{
        $online = false;   
    }
?>

    <div class="media chat-item">
                  <img alt="Sally" src="<?php echo user_image($row['user_id']) ?>" class="avatar" onError="this.onerror=null;this.src='a.jpg';">
                  <div class="media-body">
                    <div class="chat-item-title">
                    <span class="chat-item-author" data-filter-by="text">  <strong><?php echo ucwords(($row['first_name']." ".$row['last_name'])) ?>    </strong>  <span class="d-block">@<?= $row['username'] ?></span></span>
                    
                    </div>
                    <div class="chat-item-body" data-filter-by="text">
                      <p><?php echo($row['discussion']) ?></p>

                    </div>
                     <div class="d-flex gap-2 pb-2">
     <span class="badge text-bg-dark"><?= nicetime($row['date'])?></span>
     <span class="badge text-bg-light"> <a href="post-reply.php?dis=<?= $row['dis_id'] ?>">reply (<?= count_reply($row['dis_id'])  ?>)</a> </span>
     </div>
     <br/>
                  </div>
    </div>

 


 
 <?php } 
}
 ?>   
     <div>
       <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                <div class="mb-3">
                  <label for="exampleFormControlTextarea1" class="form-label">Make a post</label>
                  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                  
                  <input type="submit" class="btn btn-primary btn-sm mt-2" />
                </div>
      </form>
   </div>
  </div>
  <center>
  <nav aria-label="Page navigation example">
  <?php if (ceil($total_pages / $num_results_on_page) > 0): ?>
    <ul class="pagination">
        <?php if ($page > 1): ?>
        <li class="prev"><a href="topic-discussion.php?page=<?php echo $page-1 ?>">Prev</a></li>
        <?php endif; ?>
    
        <?php if ($page > 3): ?>
        <li class="start"><a href="topic-discussion.php?page=1">1</a></li>
        <li class="dots">...</li>
        <?php endif; ?>
    
        <?php if ($page-2 > 0): ?><li class="page"><a href="topic-discussion.php?page=<?php echo $page-2 ?>"><?php echo $page-2 ?></a></li><?php endif; ?>
        <?php if ($page-1 > 0): ?><li class="page"><a href="topic-discussion.php?page=<?php echo $page-1 ?>"><?php echo $page-1 ?></a></li><?php endif; ?>
    
        <li class="currentpage"><a href="topic-discussion.php?page=<?php echo $page ?>"><?php echo $page ?></a></li>
    
        <?php if ($page+1 < ceil($total_pages / $num_results_on_page)+1): ?><li class="page"><a href="topic-discussion.php?page=<?php echo $page+1 ?>"><?php echo $page+1 ?></a></li><?php endif; ?>
        <?php if ($page+2 < ceil($total_pages / $num_results_on_page)+1): ?><li class="page"><a href="topic-discussion.php?page=<?php echo $page+2 ?>"><?php echo $page+2 ?></a></li><?php endif; ?>
    
        <?php if ($page < ceil($total_pages / $num_results_on_page)-2): ?>
        <li class="dots">...</li>
        <li class="end"><a href="topic-discussion.php?page=<?php echo ceil($total_pages / $num_results_on_page) ?>"><?php echo ceil($total_pages / $num_results_on_page) ?></a></li>
        <?php endif; ?>
    
        <?php if ($page < ceil($total_pages / $num_results_on_page)): ?>
        <li class="next"><a href="topic-discussion.php?page=<?php echo $page+1 ?>">Next</a></li>
        <?php endif; ?>
    </ul>
    <?php endif; ?>
</nav>
</center>
  </div>
  <div class="col-4 p-3 mb-2">
  <h4>Online users</h4>      
  <div class="my-3 p-3 bg-body rounded shadow-sm">

  <?php
       $re = online_users();
     
       //var_dump($re);
      if($re->num_rows > 0){ 
       while( $r = $re->fetch_assoc()){  
        if(isset($r['user_image']))
        $fl = "users/".$r['user_id']."/img/r/".$r['user_image'];
        else
        $fl = "a.jpg";
        ?>  

    <div class="d-flex text-body-secondary pt-3 online-item" style="padding-bottom: 8px;">
     
      <img class="avatar-online"  src="<?= $fl ?>" alt="" onError="this.onerror=null;this.src='a.jpg';">
         <div class="chat-item-title">
                    <span class="chat-item-author" data-filter-by="text">  <strong><?php echo ucwords(($r['first_name']." ".$r['last_name'])) ?>    </strong>  <small class="d-block">@username</small></span>
                    
      </div>
    </div>

    <?php }
      
     ?>
   
    <small class="d-block text-end mt-3">
      <a class="btn btn-light" href="all-online-users.php?">All online users</a>
    </small>
    <?php }else{ ?>
     <center><small class="badge text-bg-warning" style="margin-top: 1.7em;">no users online</small></center>
     <?php } ?>
    

  
  </div>
</div>

</div>




</div>
<div>
 <DIV>

 </DIV>
 <DIV>

 </DIV>

</div>

</body>
<?PHP
function nicetime($date)
{
    if(empty($date)) {
        return "No date provided";
    }
    
    $periods         = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
    $lengths         = array("60","60","24","7","4.35","12","10");
    
    $now             = time();
    $unix_date       = strtotime($date);
    
       // check validity of date
    if(empty($unix_date)) {    
        return "Bad date";
    }

    // is it future date or past date
    if($now > $unix_date) {    
        $difference     = $now - $unix_date;
        $tense         = "ago";
        
    } else {
        $difference     = $unix_date - $now;
        $tense         = "from now";
    }
    
    for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
        $difference /= $lengths[$j];
    }
    
    $difference = round($difference);
    
    if($difference != 1) {
        $periods[$j].= "s";
    }
    
    return "$difference $periods[$j] {$tense}";
}


function online($date1){
    date_default_timezone_set("Africa/Lagos");
$date2=  date_create();
//var_dump($date1);
//var_dump($date2);
$t1 = strtotime( $date1 );
$t2 = strtotime( date_format($date2,"Y-m-d H:i:s"));
$diff = ($t2 - $t1) / 60;
return $diff;
}


 function online_users(){
  include "include/dbconnection.php";
  $sql = "SELECT * FROM user left join activity_log on activity_log.user_id = user.user_id left join user_profile_image on user_profile_image.`user_id`= user.user_id where TIMESTAMPDIFF(SECOND, activity_log.date_, CONCAT(CURDATE(), ' ', CURTIME())) < 6000";
  $result = $glory->query($sql);
  return $result;
  
}

function count_reply($idpost){
  include "include/dbconnection.php";
  $sql = "SELECT count(*) as c FROM `discussion_reply` WHERE `dis_id` = $idpost;";
  $result = $glory->query($sql);
  return $result->fetch_assoc()['c'];
}

function count_contributors($nub){
include "include/dbconnection.php"; 
$sql = "SELECT COUNT(*) as r FROM `discussion` WHERE `topic_id` = $nub;";
$result = $glory->query($sql);
  return $result->fetch_assoc()['r'];
}

function user_image($id){
      include "include/dbconnection.php";
  $sql = "select * from user_profile_image where user_id = $id";
  $result = $glory->query($sql);
  $img =  $result->fetch_assoc()['user_image'];
  if(isset($img))
  return "users/".$id."/img/r/".$img;
  else
  return "a.jpg";

}
    
?>
