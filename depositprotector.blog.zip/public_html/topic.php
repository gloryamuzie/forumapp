<?php
include "include/dbconnection.php";
$sql = "SELECT * FROM `topic`";
$result = $glory->query($sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <title>Topics</title>
    
<style>
    .bd-callout {
    --bs-link-color-rgb: var(--bd-callout-link);
    --bs-code-color: var(--bd-callout-code-color);
    padding: 5px;
    margin-top: 1.25rem;
    margin-bottom: 1.25rem;
    color: var(--bd-callout-color, inherit);
    background-color: var(--bd-callout-bg, var(--bs-gray-100));
    border-left: 0.25rem solid var(--bd-callout-border, var(--bs-gray-300));
}


    .heading{
        color: #20133a;
        font-size: 18px;
        font-size: 1.125rem;
        font-weight: 700;
        line-height: 24px;
        line-height: 1.5rem;
    }


    .pagination {
	list-style-type: none;
	padding: 10px 0;
	display: inline-flex;
	justify-content: space-between;
	box-sizing: border-box;
}
.pagination li {
	box-sizing: border-box;
	padding-right: 10px;
}
.pagination li a {
	box-sizing: border-box;
	background-color: #e2e6e6;
	padding: 8px;
	text-decoration: none;
	font-size: 12px;
	font-weight: bold;
	color: #616872;
	border-radius: 4px;
}
.pagination li a:hover {
	background-color: #d4dada;
}
.pagination .next a, .pagination .prev a {
	text-transform: uppercase;
	font-size: 12px;
}
.pagination .currentpage a {
	background-color: #518acb;
	color: #fff;
}
.pagination .currentpage a:hover {
	background-color: #518acb;
}


.chat-item .chat-item-title {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.375rem;
}


.avatar {
    /* width: 2.25rem; */
    height: 3.25rem;
    border-radius: 50%;
    border: 2px solid #f8f9fa;
    background: #f8f9fa;
    color: #fff;
}

.avatar-online {
    /* width: 2.25rem; */
    height: 2.45rem;
    border-radius: 50%;
    border: 2px solid #f8f9fa;
    background: #f8f9fa;
    color: #fff;
}

.media {
    display: flex;
    align-items: flex-start;
}

.chat-item > .media-body {
    margin-left: 0.75rem;
    border-radius: 0.5rem;
    
  
}

.chat-item {
    margin-top: 1.5rem;
    margin-bottom: 0.5rem;
   
}

.chat-module .chat-module-body {
    width: 100%;
    position: absolute;
    top: 4rem;
    height: calc(100% - 4rem);
    overflow-y: scroll;
    padding-right: 1.5rem;
    -ms-overflow-style: none;
}


 .chat-item:not(:last-child),   .online-item:not(:last-child){
    border-bottom: 1px solid #dee2e6;
}
</style>    
</head>
<body>
<div>
<?php include "include/navbar.php" ?>
</div>
<div class="container" style="height: 100%; margin-top: 15px;">
<ol class="list-group ">
     <?php
            if($result){
                while ($row = $result -> fetch_row()){
    ?>
 
    <li class="list-group-item  justify-content-between ">
    <span class="badge text-bg-primary rounded-pill" style="position: absolute; right: 10px"><?= count_contributors($row[0])?></span>
    <div>
        <div>
            <b>
                <a href="topic-discussion.php?id=<?php echo $row[0]?>">
                    <?= ucwords($row[1]) ?> 
                </a>
            </b>
            <div><?= $row[2]; ?></div>
            <?php 

            
                        $sql_inner = "SELECT * FROM `user` left join discussion on user.user_id = discussion.user_id WHERE `topic_id` = $row[0] ORDER BY `discussion`.`discussion` desc limit 3";  
                         $result_inner = $glory->query($sql_inner);
                         
            ?>
                    
           <?php
                         
                         while ($row__ = $result_inner -> fetch_assoc()){
            ?>
               
            <div class="bd-callout bd-callout-warning">
                 <div class="media chat-item">
                  <img alt="Sally" src="<?php echo user_image($row__['user_id']) ?>" class="avatar" onError="this.onerror=null;this.src='a.jpg';">
                  <div class="media-body">
                    <div class="chat-item-title">
                    <span class="chat-item-author" data-filter-by="text">  <strong><?php echo ucwords(($row__['first_name']." ".$row__['last_name'])) ?>    </strong>  <span class="d-block">@<?= $row__['username'] ?></span></span>
                    
                    </div>
                    <div class="chat-item-body" data-filter-by="text">
                      <p><?php echo($row__['discussion']) ?></p>

                    </div>
                     <div class="d-flex gap-2 pb-2">
     <span class="badge text-bg-dark"><?= nicetime($row__['date'])?></span>
     <span class="badge text-bg-light"> <a href="post-reply.php?dis=<?= $row__['dis_id'] ?>">reply (<?= count_reply($row__['dis_id'])  ?>)</a> </span>
     </div>
     <br/>
                  </div>
    </div>
                        </div>
            <?php
                      
                        }
                     

                          
         if($result_inner->num_rows > 0){          
                   ?>
        <a href="#">click here for more related post</a>
        </div>
        <?php } ?>
    </div>
    
    </li>
    <?php
                   
                }
               
                 
                
             }
     ?>




</ol>   
</div>

<?php include "footer.php" ?>
</body>
</html>

<?php

function count_contributors($nub){
    include "include/dbconnection.php"; 
    $sql = "SELECT COUNT(*) as r FROM `discussion` WHERE `topic_id` = $nub;";
    $result = $glory->query($sql);
      return $result->fetch_assoc()['r'];
    }
function nicetime($date)
{
    if(empty($date)) {
        return "No date provided";
    }
    
    $periods         = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
    $lengths         = array("60","60","24","7","4.35","12","10");
    
    $now             = time();
    $unix_date       = strtotime($date);
    
       // check validity of date
    if(empty($unix_date)) {    
        return "Bad date";
    }

    // is it future date or past date
    if($now > $unix_date) {    
        $difference     = $now - $unix_date;
        $tense         = "ago";
        
    } else {
        $difference     = $unix_date - $now;
        $tense         = "from now";
    }
    
    for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
        $difference /= $lengths[$j];
    }
    
    $difference = round($difference);
    
    if($difference != 1) {
        $periods[$j].= "s";
    }
    
    return "$difference $periods[$j] {$tense}";
}

function count_reply($idpost){
  include "include/dbconnection.php";
  $sql = "SELECT count(*) as c FROM `discussion_reply` WHERE `dis_id` = $idpost;";
  $result = $glory->query($sql);
  return $result->fetch_assoc()['c'];
}

function user_image($id){
      include "include/dbconnection.php";
  $sql = "select * from user_profile_image where user_id = $id";
  $result = $glory->query($sql);
  $img =  $result->fetch_assoc()['user_image'];
  if(isset($img))
  return "users/".$id."/img/r/".$img;
  else
  return "a.jpg";

}
    



?>