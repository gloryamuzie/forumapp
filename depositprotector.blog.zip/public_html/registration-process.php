<?php
session_start();

include "include/dbconnection.php";
if(empty($_POST)){
    header('location: registration.php');
}

$error = array();

$fname = $_POST['fname']; //first name of the customer
$lname = $_POST['lname']; //second name of the customer
$email = $_POST['email']; //email address of the customer
$password = $_POST['password']; //password of the customer
$address1 = $_POST['address']; //address of the customer
$address2 = $_POST['address2']; //second address of the customer
$city = $_POST['city']; //city of the customer
$country = $_POST['country']; //country of the customer
$ogaddress = $_POST['ogaddress']; //office address of the customer
$zip = $_POST['zip']; // zip code of the customer
$username = strtolower(trim($_POST['username']));
$phone_number = $_POST['phonenumber'];
$name_of_organization = $_POST['name_of_organization'];
 




if(strlen($password) < 6 ){
    $error[0] = "<b style='color: red'>Password too short</b>";
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error[1] = "<b style='color: red'>incorrect email addrerss</b>";
}

if (empty($_POST['address'])) { //b
    $error[] = "<b style='color: red'>Address is required</b>";
} //end

if (empty($_POST['city'])) {
    $error[] = "<b style='color: red'>City is required</b>";
}

if (empty($_POST['username'])){
    $error[] = "<b style='color: red'>Username is required</b>";
}
     if (!empty($_POST['username'])) {
         
            $query = "SELECT `username` FROM `user` WHERE LOWER(`username`) = '$username'";
  echo $query;
            $result = $glory->query($query); 
              if ($result->num_rows != 0){
               $error[] = "Username already exists";
              }
             
    }
  if ($_POST['country'] == -1) { 
    $error[] = "<b style='color: red'>Country is required</b>";
} 

if (empty($_POST['zip'])) { 
    $error[] = "<b style='color: red'>Zip is required</b>";
} 

if (empty($_POST['ogaddress'])) { 
    $error[] = "<b style='color: red'>Organization address is required</b>";
} 
 
if(empty($error)){
$sql = "INSERT INTO `user`( `username`, `password`, `first_name`, `last_name`, `country`, `email`, `status`, `address`, `phone_number`, `address2`, `city`, `zip`, `name_of_organiztion`, `organization_address`, `state`) VALUES ('$username','$password','$fname','$lname','$country','$email','1','$address1','$phone_number','$address2','$city','$zip','$name_of_organization','$ogaddress','no state')";
echo $sql;
$result = $glory->query($sql); 

if($result){
    $last_id = $glory->insert_id;
    mkdir("users/$last_id/profile_image");
    mkdir("users/$last_id/converted");
    mkdir("users/$last_id/profile_image/resized");
    mkdir("users/$last_id/converted");
    header("location: user-profile-page.php?id=$last_id");
    exit();
    
}
}else{
    $returned_error = implode('<br/>', $error);
    header('location: registration.php?err='.$returned_error);
    exit();

}