<!DOCTYPE html>
<?php var_dump($_GET); ?>
<html lang="en">
<head>
<meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <title>User Post</title>
</head>
<body>
<div>
<?php include "include/navbar.php" ?>
</div>
<div class="container">
  <center><h2>Posts</h2></center>
 
    <br/>
    <form action="user-post-process.php"  method="post">
    <textarea class="form-control" name="mypost"></textarea>
    <input name = "usertopic" value = "<?= $_GET['usertopic']  ?> " hidden />
    <br/>
     <center><input class="btn btn-primary" type="submit" value="submit" /></center>
    </form>
</div>
</body>