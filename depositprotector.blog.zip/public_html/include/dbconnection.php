<?php
$glory = new mysqli("localhost","u633821528_forumapp","]lzd6sR5=Jt2","u633821528_forumapp");
?>