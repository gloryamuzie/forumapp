<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include "include/script.php" ?>
    <title>Topic page</title>
</head>
<body style="height: 100%;">
<div>
<?php include "include/navbar.php" ?>
</div>
<div class="container" style="height: 100%; border: 0px solid red;">
<div class="row" style=" align-items: center; justify-content: center;">
<div class="col-sm-8">
<form action="new-topic-processor.php"  method="post">
     <h3>Create a new Topic</h3><br>
     <p><b>Topic name</b></p> 
     <input class="form-control" type="text" name="topic" required />
     <p><b>Topic Description</b></p>
     <textarea class="form-control" name="topicdescription">    </textarea>
    <br>
     <input class="btn btn-primary" type="submit" value="submit" />

    
</form>
</div>




</div>
</div>
</body>
</html>